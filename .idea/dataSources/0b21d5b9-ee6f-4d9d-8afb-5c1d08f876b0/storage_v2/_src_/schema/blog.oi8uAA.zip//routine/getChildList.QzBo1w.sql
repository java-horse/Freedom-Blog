create
    definer = root@localhost function getChildList(rootId int) returns varchar(1000)
BEGIN
    DECLARE sTemp VARCHAR(1000);
    DECLARE sTempChd VARCHAR(1000);

    SET sTemp = '$';
    SET sTempChd =cast(rootId as CHAR);

    WHILE sTempChd is not null DO
    SET sTemp = concat(sTemp,',',sTempChd);
    SELECT group_concat(id) INTO sTempChd FROM t_comment where FIND_IN_SET(parent_comment_id,sTempChd)>0;
    END WHILE;
    RETURN sTemp;
END;

